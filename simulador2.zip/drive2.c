
#include <stdio.h>
#include <termios.h>
#include <string.h>
#include <limits.h>
#include <time.h>
#include <sys/time.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
//#include <wiringPi.h>
#include <sys/types.h>
#include <sys/stat.h>
 
#define bufs 10 

time_t rawtime;
struct termios oldt,newt;
struct tm *timeinfo;
struct timeval start, ends;
FILE *fp;


int main()
{
char ttimes[20];
char toprints[]="0|0|0|0\r\0";
char a=0;
long b=0;
long c=0;
long counter=0;
tcgetattr(fileno(stdin),&oldt);
memcpy(&newt,&oldt,sizeof(struct termios));
newt.c_lflag &= ~(ECHO|ICANON);
newt.c_cc[VTIME]=0;
newt.c_cc[VMIN]=0;
tcsetattr(fileno(stdin),TCSANOW,&newt);
int ccc=0;
int fd1;
int fd2;
char buf[bufs];
char * myfifo= "/dev/drive1";
char * myfifo2= "/dev/commandss";

fd1= open (myfifo,O_WRONLY);
fd2= open (myfifo2,O_RDONLY);

b=0;


do{
gettimeofday(&start,NULL);
b=start.tv_sec;
counter=0;
buf[0]='0';
if (ccc==1) buf[0]='1';
buf[1]=buf[0];
buf[2]=buf[0];
buf[3]=buf[0];
buf[4]='\n';
buf[5]='\0';
buf[6]='\0';
write (fd1,buf,5);
read (fd2,buf,2);
ccc++;
if (ccc>1)ccc=0;
usleep(11000);
}while(buf[0]!='e'); 
fclose(fp);
oldt.c_lflag|=ECHO|ICANON;
tcsetattr(fileno(stdin),TCSANOW,&oldt);
close (fd1);
close (fd2);
return 0;
}
















