
#include <stdio.h>
#include <termios.h>
#include <string.h>
#include <limits.h>
#include <time.h>
#include <sys/time.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
//#include <wiringPi.h>
#include <sys/types.h>
#include <sys/stat.h>
 
#define bufs 10 

time_t rawtime;
struct termios oldt,newt;
struct tm *timeinfo;
struct timeval start, ends;
FILE *fp;


int main()
{
char ttimes[20];
char toprints[]="0|0|0|0\r\0";
char a=0;
long b=0;
long c=0;
long counter=0;
int ccc=0;
int fd1;
int fd2;
char buf[bufs];
char *myfifo= "drive1";
char *myfifo2= "commandss";
fd1= open (myfifo,O_WRONLY|O_NONBLOCK);
fd2= open (myfifo2,O_RDONLY|O_NONBLOCK);

b=0;

buf[2]='\n';
do{
counter=0;
buf[0]='0';
if (ccc==1) buf[0]='1';
write (fd1,buf,1);
read (fd2,buf,1);
ccc++;
if (ccc>1)ccc=0;
usleep(11000);
}while(buf[0]!='e'); 
close (fd1);
close (fd2);
return 0;
}
















