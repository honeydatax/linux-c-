
#include <stdio.h>
#include <termios.h>
#include <string.h>
#include <limits.h>
#include <time.h>
#include <sys/time.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>


#define bufs 10 


time_t rawtime;
struct termios oldt,newt;
struct tm *timeinfo;
struct timeval start, ends;
FILE *fp;

int main()
{
char ttimes[20];
char toprints[]="0|0|0|0\r\0";
char buf[bufs];
int s=0;
char a=0;
long b=0;
long c=0;
int iii=0;
int xxx=0;
int cc=0;
int tt=0;
int ttt=0;
long counter=0;
tcgetattr(fileno(stdin),&oldt);
memcpy(&newt,&oldt,sizeof(struct termios));
newt.c_lflag &= ~(ECHO|ICANON);
newt.c_cc[VTIME]=0;
newt.c_cc[VMIN]=0;
tcsetattr(fileno(stdin),TCSANOW,&newt);
int fd1;
int fd2;
char *myfifo= "drive1";
char *myfifo2= "commandss";
int ret;
mkfifo (myfifo,0700);
mkfifo (myfifo2,0700);
fd1= open (myfifo,O_RDONLY|O_NONBLOCK);
fd2= open (myfifo2,O_WRONLY|O_NONBLOCK);

b=0;
printf ("\033c");
printf ("\e[0;30;47m");
for(iii=0;iii<98;iii++){
printf ("                    ");
}

printf ("\e[1;1f\\simulator: press esc to exit");
ret=system("./drive2 &");
do{
counter=0;
a=fgetc(stdin);
printf("\e[2;%if\e[0;30;47m \e[0;30;40m ",xxx);
printf("\e[3;%if\e[0;30;47m \e[0;30;40m ",xxx);
printf("\e[4;%if\e[0;30;47m \e[0;30;40m ",xxx);
printf("\e[5;%if\e[0;30;47m \e[0;30;40m ",xxx);
printf("\e[6;%if\e[0;30;47m \e[0;30;40m ",xxx);
printf("\e[7;%if\e[0;30;47m \e[0;30;40m ",xxx);
printf("\e[8;%if\e[0;30;47m \e[0;30;40m ",xxx);
printf("\e[9;%if\e[0;30;47m \e[0;30;40m ",xxx);
printf("\e[10;%if\e[0;30;47m \e[0;30;40m ",xxx);
printf("\e[11;%if\e[0;30;47m \e[0;30;40m ",xxx);
printf("\e[12;%if\e[0;30;47m \e[0;30;40m ",xxx);
printf("\e[13;%if\e[0;30;47m \e[0;30;40m ",xxx);
printf("\e[14;%if\e[0;30;47m \e[0;30;40m ",xxx);
printf("\e[15;%if\e[0;30;47m \e[0;30;40m ",xxx);
read (fd1,buf,1);
for(iii=0;iii<4;iii++){
s=0;
if (buf[0]=='1') s=1;
tt=2+iii*3+(s);
ttt=41+s*3;
printf("\e[%i;%if\e[0;30;%im ",tt,xxx,ttt);
}
xxx++;
s++;
if (xxx>77) xxx=0;
if (s>1) s=0;
usleep(11000);
}while(a!=0x1B); 
printf ("\033c");
oldt.c_lflag|=ECHO|ICANON;
buf[0]='e';
write (fd2,buf,1);
tcsetattr(fileno(stdin),TCSANOW,&oldt);
wait(0);
usleep(2000000); 
close (fd1);
close (fd2);
return 0;
}
















